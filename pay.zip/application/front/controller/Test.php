<?php
namespace app\front\controller;

use think\Controller;
use think\Db;
use think\Log;

class Test extends Controller
{

    public function index()
    {
        return $this->fetch();
    }

    public function jump(){
    	$gate = url('front/test/api');

		$transtype = input('param.transtype'); // 9001银行卡转账 9002支付宝扫码 9003 微信扫码
		$amount = input('param.amount');
		if ($amount) {
			switch ($transtype) {
				case '9001':
					// 银联转账
					// 商户号
					$merchant_id = '1559127990317';
					// 根据不同的支付类型使用不同的回调接口
					$notify_url = 'http://'.$_SERVER['SERVER_NAME'].url('front/pay/notify_callback');
					$return_url = 'http://'.$_SERVER['SERVER_NAME'].url('front/pay/return_url');
					$order_num = time().rand(100,999);
					$key = 'c4f3fdf32bf138a80924fd19d10a84a6';
					$sign = md5($merchant_id.$amount.'.00'.$order_num.$transtype.$key);
					$this->assign('gate',$gate);
					$this->assign('merchant_id',$merchant_id);
					$this->assign('amount',$amount);
					$this->assign('order_num',$order_num);
					$this->assign('transtype',$transtype);
					$this->assign('notify_url',$notify_url);
					$this->assign('return_url',$return_url);
					$this->assign('sign',$sign);
					return $this->fetch();
					break;
				case '9002':
					// 微信转账
					// 商户号
					$merchant_id = '1559127990317';
					// 根据不同的支付类型使用不同的回调接口
					$notify_url = 'http://'.$_SERVER['SERVER_NAME'].url('front/pay/notify_callback');
					$return_url = 'http://'.$_SERVER['SERVER_NAME'].url('front/pay/return_url');
					$order_num = time().rand(100,999);
					$key = 'c4f3fdf32bf138a80924fd19d10a84a6';
					$sign = md5($merchant_id.$amount.'.00'.$order_num.$transtype.$key);
					$this->assign('gate',$gate);
					$this->assign('merchant_id',$merchant_id);
					$this->assign('amount',$amount);
					$this->assign('order_num',$order_num);
					$this->assign('transtype',$transtype);
					$this->assign('notify_url',$notify_url);
					$this->assign('return_url',$return_url);
					$this->assign('sign',$sign);
					return $this->fetch();
					break;
				case '9003':
					// 支付宝转账
					// 商户号
					$merchant_id = '1559127990317';
					// 根据不同的支付类型使用不同的回调接口
					$notify_url = 'http://'.$_SERVER['SERVER_NAME'].url('front/pay/notify_callback');
					$return_url = 'http://'.$_SERVER['SERVER_NAME'].url('front/pay/return_url');
					$order_num = time().rand(100,999);
					$key = 'c4f3fdf32bf138a80924fd19d10a84a6';
					$sign = md5($merchant_id.$amount.'.00'.$order_num.$transtype.$key);
					$this->assign('gate',$gate);
					$this->assign('merchant_id',$merchant_id);
					$this->assign('amount',$amount);
					$this->assign('order_num',$order_num);
					$this->assign('transtype',$transtype);
					$this->assign('notify_url',$notify_url);
					$this->assign('return_url',$return_url);
					$this->assign('sign',$sign);
					return $this->fetch();
					break;
				case '3001':
					// 长付
					// 商户号
					$merchant_id = '1559127990317';
					// 根据不同的支付类型使用不同的回调接口
					$notify_url = 'http://'.$_SERVER['SERVER_NAME'].url('front/pay/notify_callback');
					$return_url = 'http://'.$_SERVER['SERVER_NAME'].url('front/pay/return_url');
					$order_num = time().rand(100,999);
					$key = 'c4f3fdf32bf138a80924fd19d10a84a6';
					$sign = md5($merchant_id.$amount.'.00'.$order_num.$transtype.$key);
					$this->assign('gate',$gate);
					$this->assign('merchant_id',$merchant_id);
					$this->assign('amount',$amount);
					$this->assign('order_num',$order_num);
					$this->assign('transtype',$transtype);
					$this->assign('notify_url',$notify_url);
					$this->assign('return_url',$return_url);
					$this->assign('sign',$sign);
					return $this->fetch();
					break;
				case '3002':
					// 聚合支付
					// 商户号
					$merchant_id = '1559127990317';
					// 根据不同的支付类型使用不同的回调接口
					$notify_url = 'http://'.$_SERVER['SERVER_NAME'].url('front/pay/notify_callback');
					$return_url = 'http://'.$_SERVER['SERVER_NAME'].url('front/pay/return_url');
					$order_num = time().rand(100,999);
					$key = 'c4f3fdf32bf138a80924fd19d10a84a6';
					$sign = md5($merchant_id.$amount.'.00'.$order_num.$transtype.$key);
					$this->assign('gate',$gate);
					$this->assign('merchant_id',$merchant_id);
					$this->assign('amount',$amount);
					$this->assign('order_num',$order_num);
					$this->assign('transtype',$transtype);
					$this->assign('notify_url',$notify_url);
					$this->assign('return_url',$return_url);
					$this->assign('sign',$sign);
					return $this->fetch();
					break;
				case '3003':
					// 柠檬
					break;
				default:
					$result['code'] = '2';
					$result['msg'] = '支付类型不支持';
					break;
			}
		}else{
			$result['code'] = '1';
			$result['msg'] = '金额不正确';
		}
		return json($result);
    }

    public function return_url(){
    	return $this->fetch();
    }

    public function notify_callback(){
    	echo "SUCCESS";
    }

    public function api(){
    	$merchant_id = input('param.merchant_id'); //商户号
		$amount = (int)input('param.amount'); //支付金额
		$order_num = input('param.order_num'); //商户系统的订单号
		$transtype = input('param.transtype'); //支付类型
		$notify_url = input('param.notify_url'); //支付完成后异步通知地址，post传参
		$return_url = input('param.return_url'); //支付完成后异步通知地址，post传参
		$sign = input('param.sign'); //签名数据
		$merchant = Db::name('sfzfMerchant')->where('appid',$merchant_id)->where('status',1)->find();
		if ($merchant_id && $amount && $order_num && $transtype && $notify_url && $return_url && $sign) {
			if ($merchant) {
				// 商户账号存在
				// 根据支付类型验签
				switch ($transtype) {
					case '9001':
						// 银联支付
						$verify_sign = md5($merchant_id.$amount.'.00'.$order_num.$transtype.$merchant['appkey']);
						if ($sign == $verify_sign) {
							$channel_type_id = Db::name('sfzfChannelType')->where('pay_mode',$transtype)->value('id');
							// 获取支付通道
							$channel = Db::name('sfzfChannel')->where('merchant_id',$merchant_id)->where('channel_type_id',$channel_type_id)->where('status',1)->find();
							// 生成支付尾数
							$tails = Db::name('sfzfAmountDeliver')->where('channel_id',$channel['id'])->where('end_time','>',time())->where('amount',$amount)->column('tail');
							$temp = [];
							for ($i=1; $i < 50; $i++) { 
								if ($i < 10) {
									array_push($temp, '0'.$i);
								}else{
									array_push($temp, $i);
								}
							}
							foreach ($tails as $key => $value) {
								foreach ($temp as $t_key => $t_value) {
									if ($value == $t_value) {
										unset($temp[$t_key]);
									}
								}
							}
							$tail = array_shift($temp);
							$tail_data['channel_id'] = $channel['id'];
							$tail_data['amount'] = $amount;
							$tail_data['create_time'] = time();
							$tail_data['end_time'] = time() + $channel['timeout'];
							$tail_data['tail'] = $tail;
							Db::name('sfzfAmountDeliver')->insert($tail_data);
							// 生成订单
							$order_data['order_num'] = $order_num;
							$order_data['amount'] = $amount;
							$order_data['tail'] = $tail;
							$order_data['merchant_id'] = $merchant_id;
							$order_data['channel_id'] = $channel['id'];
							$order_data['status'] = 0;
							$order_data['create_time'] = time();
							$order_data['end_time'] = time() + $channel['timeout'];
							$order_data['notify_url'] = $notify_url;
							$order_data['return_url'] = $return_url;
							$order_data['sign_type'] = 'MD5';
							$order_data['sign'] = $sign;
							$order_data['transtype'] = $transtype;
							Db::name('sfzfOrder')->insert($order_data);
							// 跳转到付款页面
							$template = Db::name('sfzfChannelType')->where('pay_mode',$transtype)->value('template');
							session('order_num',$order_num);
							$this->redirect('front/test/'.$template,['order_num'=>$order_num]);
						}else{
							$result['status'] = 4;
							$result['msg'] = '签名错误';
						}
						break;
					case '9002':
						// 微信支付
						$verify_sign = md5($merchant_id.$amount.'.00'.$order_num.$transtype.$merchant['appkey']);
						if ($sign == $verify_sign) {
							$channel_type_id = Db::name('sfzfChannelType')->where('pay_mode',$transtype)->value('id');
							// 获取支付通道
							$channel = Db::name('sfzfChannel')->where('merchant_id',$merchant_id)->where('channel_type_id',$channel_type_id)->where('status',1)->find();
							// 生成支付尾数
							$tails = Db::name('sfzfAmountDeliver')->where('channel_id',$channel['id'])->where('end_time','>',time())->where('amount',$amount)->column('tail');
							$temp = [];
							for ($i=1; $i < 50; $i++) { 
								if ($i < 10) {
									array_push($temp, '0'.$i);
								}else{
									array_push($temp, $i);
								}
							}
							foreach ($tails as $key => $value) {
								foreach ($temp as $t_key => $t_value) {
									if ($value == $t_value) {
										unset($temp[$t_key]);
									}
								}
							}
							$tail = array_shift($temp);
							$tail_data['channel_id'] = $channel['id'];
							$tail_data['amount'] = $amount;
							$tail_data['create_time'] = time();
							$tail_data['end_time'] = time() + $channel['timeout'];
							$tail_data['tail'] = $tail;
							Db::name('sfzfAmountDeliver')->insert($tail_data);
							// 生成订单
							$order_data['order_num'] = $order_num;
							$order_data['amount'] = $amount;
							$order_data['tail'] = $tail;
							$order_data['merchant_id'] = $merchant_id;
							$order_data['channel_id'] = $channel['id'];
							$order_data['status'] = 0;
							$order_data['create_time'] = time();
							$order_data['end_time'] = time() + $channel['timeout'];
							$order_data['notify_url'] = $notify_url;
							$order_data['return_url'] = $return_url;
							$order_data['sign_type'] = 'MD5';
							$order_data['sign'] = $sign;
							$order_data['transtype'] = $transtype;
							Db::name('sfzfOrder')->insert($order_data);
							// 跳转到付款页面
							$template = Db::name('sfzfChannelType')->where('pay_mode',$transtype)->value('template');
							session('order_num',$order_num);
							$this->redirect('front/test/'.$template,['order_num'=>$order_num]);
						}else{
							$result['status'] = 4;
							$result['msg'] = '签名错误';
						}
						break;
					case '9003':
						// 支付宝支付
						$verify_sign = md5($merchant_id.$amount.'.00'.$order_num.$transtype.$merchant['appkey']);
						if ($sign == $verify_sign) {
							$channel_type_id = Db::name('sfzfChannelType')->where('pay_mode',$transtype)->value('id');
							// 获取支付通道
							$channel = Db::name('sfzfChannel')->where('merchant_id',$merchant_id)->where('channel_type_id',$channel_type_id)->where('status',1)->find();
							// 生成支付尾数
							$tails = Db::name('sfzfAmountDeliver')->where('channel_id',$channel['id'])->where('end_time','>',time())->where('amount',$amount)->column('tail');
							$temp = [];
							for ($i=1; $i < 50; $i++) { 
								if ($i < 10) {
									array_push($temp, '0'.$i);
								}else{
									array_push($temp, $i);
								}
							}
							foreach ($tails as $key => $value) {
								foreach ($temp as $t_key => $t_value) {
									if ($value == $t_value) {
										unset($temp[$t_key]);
									}
								}
							}
							$tail = array_shift($temp);
							$tail_data['channel_id'] = $channel['id'];
							$tail_data['amount'] = $amount;
							$tail_data['create_time'] = time();
							$tail_data['end_time'] = time() + $channel['timeout'];
							$tail_data['tail'] = $tail;
							Db::name('sfzfAmountDeliver')->insert($tail_data);
							// 生成订单
							$order_data['order_num'] = $order_num;
							$order_data['amount'] = $amount;
							$order_data['tail'] = $tail;
							$order_data['merchant_id'] = $merchant_id;
							$order_data['channel_id'] = $channel['id'];
							$order_data['status'] = 0;
							$order_data['create_time'] = time();
							$order_data['end_time'] = time() + $channel['timeout'];
							$order_data['notify_url'] = $notify_url;
							$order_data['return_url'] = $return_url;
							$order_data['sign_type'] = 'MD5';
							$order_data['sign'] = $sign;
							$order_data['transtype'] = $transtype;
							Db::name('sfzfOrder')->insert($order_data);
							// 跳转到付款页面
							$template = Db::name('sfzfChannelType')->where('pay_mode',$transtype)->value('template');
							session('order_num',$order_num);
							$this->redirect('front/test/'.$template,['order_num'=>$order_num]);
						}else{
							$result['status'] = 4;
							$result['msg'] = '签名错误';
						}
						break;
					case '3001':
						// 长付
						$verify_sign = md5($merchant_id.$amount.'.00'.$order_num.$transtype.$merchant['appkey']);
						if ($sign == $verify_sign) {
							$channel_type_id = Db::name('sfzfChannelType')->where('pay_mode',$transtype)->value('id');
							// 获取支付通道
							$channel = Db::name('sfzfChannel')->where('merchant_id',$merchant_id)->where('channel_type_id',$channel_type_id)->where('status',1)->find();
							$channel_cfg = Db::name('sfzfChannelConfigZl')->where('channel_id',$channel['id'])->find();
							if ($channel_cfg) {
								// 生成订单
								$order_data['order_num'] = $order_num;
								$order_data['amount'] = $amount;
								$order_data['merchant_id'] = $merchant_id;
								$order_data['channel_id'] = $channel['id'];
								$order_data['status'] = 0;
								$order_data['create_time'] = time();
								$order_data['end_time'] = time() + $channel['timeout'];
								$order_data['notify_url'] = $notify_url;
								$order_data['return_url'] = $return_url;
								$order_data['sign_type'] = 'MD5';
								$order_data['sign'] = $sign;
								$order_data['transtype'] = $transtype;
								Db::name('sfzfOrder')->insert($order_data);
								// 跳转到付款页面
								$template = Db::name('sfzfChannelType')->where('pay_mode',$transtype)->value('template');
								session('order_num',$order_num);
								$this->redirect('front/test/'.$template,['order_num'=>$order_num]);
							}else{
								$result['status'] = 5;
								$result['msg'] = '通道未配置';
							}
						}else{
							$result['status'] = 4;
							$result['msg'] = '签名错误';
						}
						break;
					case '3002':
						// 聚合支付
						$verify_sign = md5($merchant_id.$amount.'.00'.$order_num.$transtype.$merchant['appkey']);
						if ($sign == $verify_sign) {
							$channel_type_id = Db::name('sfzfChannelType')->where('pay_mode',$transtype)->value('id');
							// 获取支付通道
							$channel = Db::name('sfzfChannel')->where('merchant_id',$merchant_id)->where('channel_type_id',$channel_type_id)->where('status',1)->find();
							$channel_cfg = Db::name('sfzfChannelConfigZl')->where('channel_id',$channel['id'])->find();
							if ($channel_cfg) {
								// 生成订单
								$order_data['order_num'] = $order_num;
								$order_data['amount'] = $amount;
								$order_data['merchant_id'] = $merchant_id;
								$order_data['channel_id'] = $channel['id'];
								$order_data['status'] = 0;
								$order_data['create_time'] = time();
								$order_data['end_time'] = time() + $channel['timeout'];
								$order_data['notify_url'] = $notify_url;
								$order_data['return_url'] = $return_url;
								$order_data['sign_type'] = 'MD5';
								$order_data['sign'] = $sign;
								$order_data['transtype'] = $transtype;
								Db::name('sfzfOrder')->insert($order_data);
								// 跳转到付款页面
								$template = Db::name('sfzfChannelType')->where('pay_mode',$transtype)->value('template');
								session('order_num',$order_num);
								$this->redirect('front/test/'.$template,['order_num'=>$order_num]);
							}else{
								$result['status'] = 5;
								$result['msg'] = '通道未配置';
							}
						}else{
							$result['status'] = 4;
							$result['msg'] = '签名错误';
						}
						break;
					default:
						$result['status'] = 3;
						$result['msg'] = '不支持的支付类型';
						break;
				}
			}else{
				$result['status'] = 2;
				$result['msg'] = '商户未开通';
			}
		}else{
			$result['status'] = 1;
			$result['msg'] = '参数不全';
		}
		return json($result);
    }
    // 支付宝跳转二维码链接
    public function qrlink(){
    	$order_num = input('param.order_num');
    	$order = Db::name('sfzfOrder')->where('order_num',$order_num)->find();
    	$channel_cfg = Db::name('sfzfChannelConfigZz')->where('channel_id',$order['channel_id'])->find();

    	$link = "alipays://platformapi/startapp?appId=09999988&actionType=toCard&sourceId=bill&cardNo=6".$channel_cfg['show_number']." &bankAccount=".$channel_cfg['acount_name']."&bankMark=".$channel_cfg['bankMark']."&bankName=".$channel_cfg['bank_name']."&money=".$order['amount'].'.'.$order['tail']."&amount=".$order['amount'].'.'.$order['tail']."&cardIndex=".$channel_cfg['cardIndex']."&cardNoHidden=true&cardChannel=HISTORY_CARD&orderSource=from";
    	$this->redirect($link);
    }
    public function ajax(){
    	$order_num = input('param.order_num');
    	$merchant_id = input('param.merchant_id');
    	$sign = input('param.sign');
    	$order = Db::name('sfzfOrder')->where('order_num',$order_num)->where('merchant_id',$merchant_id)->where('sign',$sign)->find();
		if ($order) {
			$order_data['merchant_id'] = $order['merchant_id'];
			$order_data['order_num'] = $order['order_num'];
			$order_data['status'] = $order['status'];
			$order_data['amount'] = $order['amount'];
			$order_data['create_time'] = $order['create_time'];
			$order_data['pay_time'] = $order['pay_time'];
			$result['status'] = 0;
			$result['msg'] = '订单获取成功';
			$result['data'] = $order_data;
		}else{
			$result['status'] = -1;
			$result['msg'] = '订单不存在';
		}
		return json($result);
    }
    // 银联页面
    public function yl(){
    	$order_num = session('order_num');
    	if ($order_num) {
    		$order = Db::name('sfzfOrder')->where('order_num',$order_num)->find();
    		if (time() < $order['end_time']) {
    			$channel = Db::name('sfzfChannelConfigZz')->where('channel_id',$order['channel_id'])->select();
    			$this->assign('order',$order);
    			$this->assign('channel',$channel);
    			$time_limit = $order['end_time'] - time();
    			$m = floor($time_limit / 60);
    			$s = $time_limit % 60;
    			
    			$this->assign('m',$m);
    			$this->assign('s',$s);
    			dump($channel);
    			// return $this->fetch();
    		}else{
    			$this->redirect('front/pay/expire');
    		}
    	}else{
    		$this->redirect('front/pay/expire');
    	}
    }
    // 支付宝页面
    public function zfb(){
    	$order_num = session('order_num');
    	if ($order_num) {
    		$order = Db::name('sfzfOrder')->where('order_num',$order_num)->find();
    		if (time() < $order['end_time']) {
    			$channel = Db::name('sfzfChannelConfigZz')->where('channel_id',$order['channel_id'])->find();
    			$this->assign('order',$order);
    			$this->assign('channel',$channel);
    			$time_limit = $order['end_time'] - time();
    			$m = floor($time_limit / 60);
    			$s = $time_limit % 60;
    			$this->assign('m',$m);
    			$this->assign('s',$s);
    			$alipay_jump = 'http://'.$_SERVER['SERVER_NAME'].url('front/pay/qrlink').'?order_num='.$order_num;
    			$this->assign('alipay_jump',$alipay_jump);
    			return $this->fetch();
    		}else{
    			$this->redirect('front/pay/expire');
    		}
    	}else{
    		$this->redirect('front/pay/expire');
    	}
    }

    // 微信页面
    public function wx(){
    	$order_num = session('order_num');
    	if ($order_num) {
    		$order = Db::name('sfzfOrder')->where('order_num',$order_num)->find();
    		if (time() < $order['end_time']) {
    			$channel = Db::name('sfzfChannelConfigZz')->where('channel_id',$order['channel_id'])->find();
    			$this->assign('order',$order);
    			$this->assign('channel',$channel);
    			$time_limit = $order['end_time'] - time();
    			$m = floor($time_limit / 60);
    			$s = $time_limit % 60;
    			$this->assign('m',$m);
    			$this->assign('s',$s);
    			return $this->fetch();
    		}else{
    			$this->redirect('front/pay/expire');
    		}
    	}else{
    		$this->redirect('front/pay/expire');
    	}
    }
    // 长付跳转页面
    public function changfu(){
    	$order_num = session('order_num');
    	if ($order_num) {
    		$order = Db::name('sfzfOrder')->where('order_num',$order_num)->find();
    		if (time() < $order['end_time']) {
    			$channel = Db::name('sfzfChannelConfigZl')->where('channel_id',$order['channel_id'])->find();
    			$this->assign('order',$order);
    			$this->assign('channel',$channel);
    			$p0_Version = '1.0';
    			$p1_MerchantNo = $channel['thr_appid'];
    			$p2_OrderNo = $order['order_num'];
    			$p3_Amount = $order['amount'];
    			$p4_Cur = '1';
    			$p5_ProductName = '双龙娱乐';
    			$p9_NotifyUrl = 'http://'.$_SERVER['SERVER_NAME'].url('front/test/client_callback_3001');
    			$q1_FrpCode = 'ALIPAY_NATIVE';

    			$key = $channel['thr_appkey'];

    			$hmac = md5($p0_Version.$p1_MerchantNo.$p2_OrderNo.$p3_Amount.$p4_Cur.$p5_ProductName.$p9_NotifyUrl.$q1_FrpCode.$key);
    			
    			$paygate = $channel['paygate'];
    			//初始化
				$curl = curl_init();
				//设置抓取的url
				curl_setopt($curl, CURLOPT_URL, $paygate);
				//设置获取的信息以文件流的形式返回，而不是直接输出。
				curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
				//设置post方式提交
				curl_setopt($curl, CURLOPT_POST, 1);
				//设置post数据
				$post_data = array(
			        "p0_Version" => $p0_Version,
			        "p1_MerchantNo" => $p1_MerchantNo,
			        "p2_OrderNo" => $p2_OrderNo,
			        "p3_Amount" => $p3_Amount,
			        "p4_Cur" => $p4_Cur,
			        "p5_ProductName" => $p5_ProductName,
			        "p9_NotifyUrl" => $p9_NotifyUrl,
			        "q1_FrpCode" => $q1_FrpCode,
			        "hmac" => $hmac
			    );
			    curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
			    //执行命令
			    $data = curl_exec($curl);
			    //关闭URL请求
			    curl_close($curl);
			    // 2019年06月18日15:40:08 长付通道未开放 需在2019年06月19日开放后继续开发
			    dump($data);

    			return $this->fetch();
    		}else{
    			$this->redirect('front/pay/expire');
    		}
    	}else{
    		$this->redirect('front/pay/expire');
    	}
    }
    // 聚合支付
    public function juhe(){
    	$order_num = session('order_num');
    	if ($order_num) {
    		$order = Db::name('sfzfOrder')->where('order_num',$order_num)->find();
    		if (time() < $order['end_time']) {
    			$channel = Db::name('sfzfChannelConfigZl')->where('channel_id',$order['channel_id'])->find();
    			$this->assign('order',$order);
    			$this->assign('channel',$channel);
    			$pay_memberid = $channel['thr_appid'];   //商户ID
				$pay_orderid = $order_num;    //订单号
				$pay_amount = $order['amount'];    //交易金额
				$pay_applydate = date("Y-m-d H:i:s");  //订单时间
				$pay_notifyurl = 'http://'.$_SERVER['SERVER_NAME'].url('front/test/client_callback_3002');   //服务端返回地址
				$pay_callbackurl = $order['return_url'];  //页面跳转返回地址
				$Md5key = $channel['thr_appkey'];   //密钥
				$paygate = $channel['paygate'];   //提交地址
				$pay_bankcode = "904";   //银行编码
				//扫码
				$native = array(
				    "pay_memberid" => $pay_memberid,
				    "pay_orderid" => $pay_orderid,
				    "pay_amount" => $pay_amount,
				    "pay_applydate" => $pay_applydate,
				    "pay_bankcode" => $pay_bankcode,
				    "pay_notifyurl" => $pay_notifyurl,
				    "pay_callbackurl" => $pay_callbackurl,
				);
				ksort($native);
				$md5str = "";
				foreach ($native as $key => $val) {
				    $md5str = $md5str . $key . "=" . $val . "&";
				}
				//echo($md5str . "key=" . $Md5key);
				$sign = strtoupper(md5($md5str . "key=" . $Md5key));
				$native["pay_md5sign"] = $sign;
				$native['pay_attach'] = "1234|456";
				$native['pay_productname'] ='VIP基础服务';
				$this->assign('native',$native);
				$this->assign('paygate',$paygate);
    			return $this->fetch();
    		}else{
    			$this->redirect('front/pay/expire');
    		}
    	}else{
    		$this->redirect('front/pay/expire');
    	}
    }


    public function expire(){
    	return $this->fetch();
    }

    public function client_get_order(){
    	$channel_id = input('param.channel_id');
    	$sign = input('param.sign');
    	if ($channel_id && $sign) {
    		$client_sign = Db::name('sfzfChannelConfigZz')->where('channel_id',$channel_id)->value('client_sign');
	    	if ($client_sign == $sign) {
	    		$order = Db::name('sfzfOrder')->where('channel_id',$channel_id)->whereTime('create_time','today')->order('create_time desc')->select();
	    		$result['status'] = 0;
	    		$result['msg'] = 'ok';
	    		$result['data'] = $order;
	    	}else{
	    		$result['status'] = 1;
	    		$result['msg'] = '验证不通过';
	    	}
    	}else{
    		$result['status'] = 2;
    		$result['msg'] = '参数不全';
    	}
    	return json($result);
    }

    // 短信客户端回调
    public function client_callback(){
    	$sign = input('param.sign');
    	$tel = input('param.tel');
    	$content = input('param.content');
    	if ($sign) {
    		$channel_config = Db::name('sfzfChannelConfigZz')->where('client_sign',$sign)->find();
	    	if ($channel_config) {
	    		switch ($tel) {
	    			// 建设银行
	    			case '95533':
	    				if (ccb_check($content,$bank_tail,$amount,$amount_tail)) {
	    					$order = Db::name('sfzfOrder')->where('channel_id',$channel_config['channel_id'])->where('amount',$amount)->where('tail',$amount_tail)->where('end_time','>',time())->find();
							if ($order) {
								Db::name('sfzfOrder')->where('channel_id',$channel_config['channel_id'])->where('amount',$amount)->where('tail',$amount_tail)->where('end_time','>',time())->update(['status'=>1,'pay_time'=>time()]);
								Db::name('sfzfMerchant')->where('appid',$order['merchant_id'])->setInc('money',$order['amount'].'.'.$order['tail']);
								//初始化
								$curl = curl_init();
								//设置抓取的url
								curl_setopt($curl, CURLOPT_URL, $order['notify_url']);
								//设置获取的信息以文件流的形式返回，而不是直接输出。
								curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
								//设置post方式提交
								curl_setopt($curl, CURLOPT_POST, 1);
								//设置post数据
								$post_data = array(
							        "merchant_id" => $order['merchant_id'],
							        "order_num" => $order['order_num'],
							        "status" => 1,
							        "amount" => $order['amount'].'.00',
							        "create_time" => $order['create_time'],
							        "pay_time" => time(),
							        "sign" => $order['sign'],
							    );
							    curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
							    //执行命令
							    $data = curl_exec($curl);
							    //关闭URL请求
							    curl_close($curl);
							    //显示获得的数据
							    if (strtoupper($data) == "SUCCESS") {
							    	Db::name('sfzfOrder')->where('channel_id',$channel_config['channel_id'])->where('amount',$amount)->where('tail',$amount_tail)->where('end_time','>',time())->update(['notify_status'=>1]);
							    	$result['status'] = 0;
							    	$result['msg'] = '通知成功';
							    }else{
							    	$result['status'] = 3;
							    	$result['msg'] = '通知失败';
							    }
    						}else{
    							$result['status'] = 2;
								$result['msg'] = '订单不存在';
    						}
	    				}else{
	    					$result['status'] = 3;
		    				$result['msg'] = '格式错误';
	    				}
	    				break;
	    			// 中国银行
	    			case '95566':
	    				if (boc_check($content,$bank_tail,$amount,$amount_tail)) {
	    					$order = Db::name('sfzfOrder')->where('channel_id',$channel_config['channel_id'])->where('amount',$amount)->where('tail',$amount_tail)->where('end_time','>',time())->find();
							if ($order) {
								Db::name('sfzfOrder')->where('channel_id',$channel_config['channel_id'])->where('amount',$amount)->where('tail',$amount_tail)->where('end_time','>',time())->update(['status'=>1,'pay_time'=>time()]);
								Db::name('sfzfMerchant')->where('appid',$order['merchant_id'])->setInc('money',$order['amount'].'.'.$order['tail']);
								//初始化
								$curl = curl_init();
								//设置抓取的url
								curl_setopt($curl, CURLOPT_URL, $order['notify_url']);
								//设置获取的信息以文件流的形式返回，而不是直接输出。
								curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
								//设置post方式提交
								curl_setopt($curl, CURLOPT_POST, 1);
								//设置post数据
								$post_data = array(
							        "merchant_id" => $order['merchant_id'],
							        "order_num" => $order['order_num'],
							        "status" => 1,
							        "amount" => $order['amount'].'.00',
							        "create_time" => $order['create_time'],
							        "pay_time" => time(),
							        "sign" => $order['sign'],
							    );
							    curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
							    //执行命令
							    $data = curl_exec($curl);
							    //关闭URL请求
							    curl_close($curl);
							    //显示获得的数据
							    if (strtoupper($data) == "SUCCESS") {
							    	Db::name('sfzfOrder')->where('channel_id',$channel_config['channel_id'])->where('amount',$amount)->where('tail',$amount_tail)->where('end_time','>',time())->update(['notify_status'=>1]);
							    	$result['status'] = 0;
							    	$result['msg'] = '通知成功';
							    }else{
							    	$result['status'] = 3;
							    	$result['msg'] = '通知失败';
							    }
    						}else{
    							$result['status'] = 2;
								$result['msg'] = '订单不存在';
    						}
	    				}else{
	    					$result['status'] = 3;
		    				$result['msg'] = '格式错误';
	    				}
	    				break;
	    			default:
	    				$result['status'] = 4;
	    				$result['msg'] = '不匹配';
	    				break;
	    		}
	    	}else{
	    		$result['status'] = 1;
				$result['msg'] = '签名错误';
			}
		}else{
			$result['status'] = 2;
			$result['msg'] = '签名为空';
		}
		
		return json($result);
    }
    // 长付跳转回调
    public function client_callback_3001(){
    	echo "3001";
    }
    // 聚合支付跳转回调
	public function client_callback_3002(){
		$memberid = input('param.memberid');
		$sign = input('param.sign');
		$Md5key = Db::name('sfzfChannelConfigZl')->where('thr_appid',$memberid)->value('thr_appkey');
		if ($Md5key) {
			$native = array(
				"memberid" => input('param.memberid'),
				"orderid" => input('param.orderid'),
				"transaction_id" => input('param.transaction_id'),
				"amount" => input('param.amount'),
				"datetime" => input('param.datetime'),
				"returncode" => input('param.returncode')
			);
			ksort($native);
			$md5str = "";
			foreach ($native as $key => $val) {
				$md5str = $md5str . $key . "=" . $val . "&";
			}
			$verify_sign = strtoupper(md5($md5str . "key=" . $Md5key));
			if ($verify_sign == $sign) {
				$order = Db::name('sfzfOrder')->where('order_num',input('param.orderid'))->find();
				Db::name('sfzfOrder')->where('order_num',input('param.orderid'))->update(['status'=>1,'pay_time'=>time()]);
				//初始化
				$curl = curl_init();
				//设置抓取的url
				curl_setopt($curl, CURLOPT_URL, $order['notify_url']);
				//设置获取的信息以文件流的形式返回，而不是直接输出。
				curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
				//设置post方式提交
				curl_setopt($curl, CURLOPT_POST, 1);
				//设置post数据
				$post_data = array(
			        "merchant_id" => $order['merchant_id'],
			        "order_num" => $order['order_num'],
			        "status" => 1,
			        "amount" => $order['amount'].'.00',
			        "create_time" => $order['create_time'],
			        "pay_time" => time(),
			        "sign" => $order['sign'],
			    );
			    curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
			    //执行命令
			    $data = curl_exec($curl);
			    //关闭URL请求
			    curl_close($curl);
			    //显示获得的数据
			    if (strtoupper($data) == "SUCCESS") {
			    	Db::name('sfzfOrder')->where('order_num',$order['order_num'])->update(['notify_status'=>1]);
			    	// 通知成功
			    	echo "OK";
			    }else{
			    	// 通知失败
			    	echo "Fail";
			    }
			}else{
				// 验签失败
				echo "Fail";
			}
    	}else{
    		// 商户号错误
    		echo "Fail";
    	}
    }

    

	public function test(){
		$content = input('param.content');
		// $pattern = '/您的借记卡账户([\d]{4})，于(.*)网上支付收入人民币([\d]+)\.([\d]{2})元/';
		// preg_match($pattern, $content, $bank_matches);
		// dump($bank_matches);
		$pattern = [
			'/您的借记卡账户(\d{4}).于\d+月\d+日(\d+时\d+分)?(网上支付收入|收入\(网银跨行\)|POS收入)人民币(\d+)\.(\d{2})元.交易后余额(\d+\.?\d+).中国银行./',
			'/您的借记卡账户([\d]{4})[,，]于(.*)收入\(网银跨行\)人民币([\d]+)\.([\d]{2})元(,|，)交易后余额(.*)(\[|【)中国银行[\]|】]/',
			'/您的借记卡账户(\d{4})，于(.*)网上支付收入人民币([\d]+)\.([\d]{2})元/'
		];
		$bank_matches = [];
		foreach ($pattern as $key => $value) {
			echo $value."<br>";
			echo $content."<br>";
			preg_match($value, $content, $bank_matches);
			dump($bank_matches);
			if (isset($bank_matches[0]) && isset($bank_matches[1]) && isset($bank_matches[2])) {
				break;
			}
		}
		if (isset($bank_matches[0]) && isset($bank_matches[1]) && isset($bank_matches[2])) {
			echo $bank_matches[0]."-".$bank_matches[1]."-".$bank_matches[2];
		}else{
			echo "没有匹配";
		}
	}

    public function heartbeat(){
    	$result['status'] = 0;
    	$result['msg'] = '心跳同步成功';
    	$result['time'] = time();
    	return json($result);
    }
}
