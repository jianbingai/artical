<?php
namespace app\sfpay\controller;

use controller\BasicAdmin;
use service\DataService;
use think\Db;


class Merchant extends BasicAdmin
{

    public $table = 'sfzfMerchant';

    public function index()
    {
        $this->title = '商户管理';
        list($get, $db) = [$this->request->get(), Db::name($this->table)];
        foreach (['name', 'contact'] as $key) {
            (isset($get[$key]) && $get[$key] !== '') && $db->whereLike($key, "%{$get[$key]}%");
        }
        return parent::_list($db);
    }

    public function item(){
        $merchant = Db::name($this->table)->where('id',2)->find();
        $this->assign('merchant',$merchant);
        return $this->fetch();
    }


    public function add()
    {
        return $this->_form($this->table, 'form');
    }

    public function edit()
    {
        return $this->_form($this->table, 'form');
    }


    public function _form_filter(&$data)
    {
        if ($this->request->isPost()) {
            if (isset($data['id'])) {
                unset($data['username']);
            } elseif (Db::name($this->table)->where(['name' => $data['name']])->count() > 0) {
                $this->error('商户名称已经存在，请使用其它账号！');
            } else{
            	$data['appid'] = time().rand(100,999);
            	$data['appkey'] = md5(time().rand(100,999));
            	$data['status'] = 1;
            	$data['create_time'] = time();
            }
        }
    }

    public function del()
    {
        if (DataService::update($this->table)) {
            $this->success("商户删除成功！", '');
        }
        $this->error("商户删除失败，请稍候再试！");
    }

    public function forbid()
    {
        if (DataService::update($this->table)) {
            $this->success("用户禁用成功！", '');
        }
        $this->error("商户禁用失败，请稍候再试！");
    }

    public function resume()
    {
        if (DataService::update($this->table)) {
            $this->success("用户启用成功！", '');
        }
        $this->error("商户启用失败，请稍候再试！");
    }

}
