<?php
namespace app\sfpay\controller;

use controller\BasicAdmin;
use service\DataService;
use think\Db;


class Channeltypefield extends BasicAdmin
{

    public $table = 'sfzfChannelTypeField';

    public function index()
    {
        $this->title = '通道分类字段管理';
        list($get, $db) = [$this->request->get(), Db::name($this->table)];
        foreach (['name', 'contact'] as $key) {
            (isset($get[$key]) && $get[$key] !== '') && $db->whereLike($key, "%{$get[$key]}%");
        }
        $channel_type_id = input('param.id');
        $this->assign('channel_type_id',$channel_type_id);
        return parent::_list($db->where('channel_type_id',$channel_type_id));
    }


    public function add()
    {
        return $this->_form($this->table, 'form');
    }

    public function edit()
    {
        return $this->_form($this->table, 'form');
    }


    public function _form_filter(&$data)
    {
        if ($this->request->isPost()) {
            if (!isset($data['id'])) {
                if (Db::name($this->table)->where(['field_name' => $data['field_name']])->count() > 0) {
                    $this->error('通道分类名称已经存在，请使用其它账号！');
                }
            }
        }else{
            if (input('param.channel_type_id')) {
                $data['channel_type_id'] = input('param.channel_type_id');
            }
        }
    }

    public function del()
    {
        if (DataService::update($this->table)) {
            $this->success("通道分类删除成功！", '');
        }
        $this->error("通道分类删除失败，请稍候再试！");
    }

    public function forbid()
    {
        if (DataService::update($this->table)) {
            $this->success("用户禁用成功！", '');
        }
        $this->error("通道分类禁用失败，请稍候再试！");
    }

    public function resume()
    {
        if (DataService::update($this->table)) {
            $this->success("用户启用成功！", '');
        }
        $this->error("通道分类启用失败，请稍候再试！");
    }

}
