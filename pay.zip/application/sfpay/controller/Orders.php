<?php
namespace app\sfpay\controller;

use controller\BasicAdmin;
use service\DataService;
use think\Db;


class Orders extends BasicAdmin
{

    public $table = 'sfzfOrder';

    public function index()
    {
        $this->title = '订单管理';
        list($get, $db) = [$this->request->get(), Db::name($this->table)];
        foreach (['order_num'] as $key) {
            (isset($get[$key]) && $get[$key] !== '') && $db->whereLike($key, "%{$get[$key]}%");
        }
        if (isset($get['status']) && $get['status'] !== '') {
            $db->where('status', $get['status']);
        }
        if (isset($get['create_time']) && $get['create_time'] !== '') {
            list($start, $end) = explode(' - ', $get['create_time']);
            $db->whereBetween('create_time', [strtotime("{$start} 00:00:00"), strtotime("{$end} 23:59:59")]);
        }
        return parent::_list($db->order('create_time desc'));
    }


    public function del()
    {
        if (DataService::update($this->table)) {
            $this->success("订单删除成功！", '');
        }
        $this->error("订单删除失败，请稍候再试！");
    }

    public function reissue(){
        $id = input('param.id');
        if ($id) {
            $order = Db::name('sfzfOrder')->where('id',$id)->find();

            Db::name('sfzfOrder')->where('id',$id)->update(['status'=>1,'pay_time'=>time()]);
            //初始化
            $curl = curl_init();
            //设置抓取的url
            curl_setopt($curl, CURLOPT_URL, $order['notify_url']);
            //设置获取的信息以文件流的形式返回，而不是直接输出。
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            //设置post方式提交
            curl_setopt($curl, CURLOPT_POST, 1);
            //设置post数据
            $post_data = array(
                "merchant_id" => $order['merchant_id'],
                "order_num" => $order['order_num'],
                "status" => $order['status'],
                "amount" => $order['amount'].'.00',
                "create_time" => $order['create_time'],
                "pay_time" => $order['pay_time'],
                "sign" => $order['sign'],
                );
            curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
            //执行命令
            $data = curl_exec($curl);
            //关闭URL请求
            curl_close($curl);
            //显示获得的数据
            if ($data == "SUCCESS") {
                Db::name('sfzfOrder')->where('id',$id)->update(['notify_status'=>1]);
                $this->success('通知成功','');
            }else{
                $this->success('通知失败','');
            }
        }else{
            $this->error('参数错误');
        }
    }


}
