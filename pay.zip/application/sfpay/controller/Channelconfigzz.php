<?php
namespace app\sfpay\controller;

use controller\BasicAdmin;
use service\DataService;
use think\Db;


class Channelconfigzz extends BasicAdmin
{

    public $table = 'sfzfChannelConfigZz';

    public function index()
    {
        $channel_id = input('param.channel_id');
        if ($channel_id) {
            $this->title = '通道配置管理';
            list($get, $db) = [$this->request->get(), Db::name($this->table)];
            foreach (['name', 'contact'] as $key) {
                (isset($get[$key]) && $get[$key] !== '') && $db->whereLike($key, "%{$get[$key]}%");
            }
            return parent::_list($db->where('channel_id',$channel_id));
        }else{
            $this->error('通道号为空');
        }
    }


    public function add()
    {
        return $this->_form($this->table, 'form');
    }

    public function edit()
    {
        return $this->_form($this->table, 'form');
    }


    public function _form_filter(&$data)
    {
        if ($this->request->isPost()) {
            
        }
    }

    public function del()
    {
        if (DataService::update($this->table)) {
            $this->success("通道配置删除成功！", '');
        }
        $this->error("通道配置删除失败，请稍候再试！");
    }

    public function forbid()
    {
        if (DataService::update($this->table)) {
            $this->success("用户禁用成功！", '');
        }
        $this->error("通道配置禁用失败，请稍候再试！");
    }

    public function resume()
    {
        if (DataService::update($this->table)) {
            $this->success("用户启用成功！", '');
        }
        $this->error("通道配置启用失败，请稍候再试！");
    }

}
