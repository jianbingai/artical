<?php
namespace app\sfpay\controller;

use controller\BasicAdmin;
use service\DataService;
use think\Db;


class Channel extends BasicAdmin
{

    public $table = 'sfzfChannel';

    public function index()
    {
        $mode = input('param.mode');
        $this->title = '通道管理';
        list($get, $db) = [$this->request->get(), Db::name($this->table)];
        foreach (['name', 'contact'] as $key) {
            (isset($get[$key]) && $get[$key] !== '') && $db->whereLike($key, "%{$get[$key]}%");
        }
        $this->assign('mode',$mode);
        return parent::_list($db->where('mode',$mode));
    }


    public function add()
    {
        return $this->_form($this->table, 'form');
    }

    public function edit()
    {
        return $this->_form($this->table, 'form');
    }


    public function _form_filter(&$data)
    {
        if ($this->request->isPost()) {
            if (!isset($data['id'])) {
                $data['create_time'] = time();
                if (Db::name($this->table)->where(['name' => $data['name']])->count() > 0) {
                    $this->error('通道名称已经存在，请使用其它账号！');
                }
            }
        }else{
            $mode = input('param.mode');
            if ($mode) {
                $data['mode'] = $mode;
                $channel_type = Db::name('sfzfChannelType')->where('mode',$mode)->select();
                $this->assign('channel_type',$channel_type);
                switch ($mode) {
                    case 'zz':
                        if (isset($data['id'])) {
                            $data_zz = Db::name('sfzfChannelConfigZz')->where('channel_id',$data['id'])->find();
                            if ($data_zz) {
                                $data['bank_name'] = $data_zz['bank_name'];
                                $data['acount_name'] = $data_zz['acount_name'];
                                $data['acount_number'] = $data_zz['acount_number'];
                                $data['bank_deposit'] = $data_zz['bank_deposit'];
                                $data['show_number'] = $data_zz['show_number'];
                                $data['cardIndex'] = $data_zz['cardIndex'];
                                $data['bankMark'] = $data_zz['bankMark'];
                                $data['client_sign'] = $data_zz['client_sign'];
                                
                            }
                        }
                        break;
                    case 'zl':
                        if (isset($data['id'])) {
                            $data_zl = Db::name('sfzfChannelConfigZl')->where('channel_id',$data['id'])->find();
                            if ($data_zl) {
                                $data['paygate'] = $data_zl['paygate'];
                                $data['max_due'] = $data_zl['max_due'];
                                $data['min_due'] = $data_zl['min_due'];
                                $data['thr_appid'] = $data_zl['thr_appid'];
                                $data['thr_appkey'] = $data_zl['thr_appkey'];
                            }
                        }
                        break;
                    default:
                        # code...
                        break;
                }
                $merchant = Db::name('sfzfMerchant')->where('status',1)->select();
                $this->assign('merchant',$merchant);
            }
            
        }
    }

    public function _form_result($result,$data){
        if ($result) {
            switch ($data['mode']) {
                case 'zz':
                    $channel_config_zz['channel_id'] = Db::name($this->table)->where('name',$data['name'])->value('id');
                    $channel_config_zz['bank_name'] = $data['bank_name'];
                    $channel_config_zz['acount_name'] = $data['acount_name'];
                    $channel_config_zz['acount_number'] = $data['acount_number'];
                    $channel_config_zz['bank_deposit'] = $data['bank_deposit'];
                    $channel_config_zz['show_number'] = $data['show_number'];
                    $channel_config_zz['cardIndex'] = $data['cardIndex'];
                    $channel_config_zz['bankMark'] = $data['bankMark'];
                    $channel_config_zz['client_sign'] = $data['client_sign'];
                    if (Db::name('sfzfChannelConfigZz')->where('channel_id',$channel_config_zz['channel_id'])->find()) {
                        Db::name('sfzfChannelConfigZz')->where('channel_id',$channel_config_zz['channel_id'])->update($channel_config_zz);
                    }else{
                        Db::name('sfzfChannelConfigZz')->insert($channel_config_zz);
                    }
                    break;
                case 'zl':
                    $channel_config_zl['channel_id'] = Db::name($this->table)->where('name',$data['name'])->value('id');
                    $channel_config_zl['paygate'] = $data['paygate'];
                    $channel_config_zl['max_due'] = $data['max_due'];
                    $channel_config_zl['min_due'] = $data['min_due'];
                    $channel_config_zl['thr_appid'] = $data['thr_appid'];
                    $channel_config_zl['thr_appkey'] = $data['thr_appkey'];
                    if (Db::name('sfzfChannelConfigZl')->where('channel_id',$channel_config_zl['channel_id'])->find()) {
                        Db::name('sfzfChannelConfigZl')->where('channel_id',$channel_config_zl['channel_id'])->update($channel_config_zl);
                    }else{
                        Db::name('sfzfChannelConfigZl')->insert($channel_config_zl);
                    }
                    break;
                default:
                    # code...
                    break;
            }
            
        }
    }

    public function del()
    {
        if (DataService::update($this->table)) {
            $this->success("通道删除成功！", '');
        }
        $this->error("通道删除失败，请稍候再试！");
    }

    public function forbid()
    {
        if (DataService::update($this->table)) {
            $this->success("用户禁用成功！", '');
        }
        $this->error("通道禁用失败，请稍候再试！");
    }

    public function resume()
    {
        if (DataService::update($this->table)) {
            $this->success("用户启用成功！", '');
        }
        $this->error("通道启用失败，请稍候再试！");
    }

}
