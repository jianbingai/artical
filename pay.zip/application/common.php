<?php

// +----------------------------------------------------------------------
// | ThinkAdmin
// +----------------------------------------------------------------------
// | 版权所有 2014~2017 广州楚才信息科技有限公司 [ http://www.cuci.cc ]
// +----------------------------------------------------------------------
// | 官方网站: http://think.ctolog.com
// +----------------------------------------------------------------------
// | 开源协议 ( https://mit-license.org )
// +----------------------------------------------------------------------
// | github开源项目：https://github.com/zoujingli/ThinkAdmin
// +----------------------------------------------------------------------

use service\DataService;
use service\NodeService;
use think\Db;

/**
 * 打印输出数据到文件
 * @param mixed $data 输出的数据
 * @param bool $force 强制替换
 * @param string|null $file
 */
function p($data, $force = false, $file = null)
{
    is_null($file) && $file = env('runtime_path') . date('Ymd') . '.txt';
    $str = (is_string($data) ? $data : (is_array($data) || is_object($data)) ? print_r($data, true) : var_export($data, true)) . PHP_EOL;
    $force ? file_put_contents($file, $str) : file_put_contents($file, $str, FILE_APPEND);
}

/**
 * RBAC节点权限验证
 * @param string $node
 * @return bool
 */
function auth($node)
{
    return NodeService::checkAuthNode($node);
}

/**
 * 设备或配置系统参数
 * @param string $name 参数名称
 * @param bool $value 默认是null为获取值，否则为更新
 * @return string|bool
 * @throws \think\Exception
 * @throws \think\exception\PDOException
 */
function sysconf($name, $value = null)
{
    static $config = [];
    if ($value !== null) {
        list($config, $data) = [[], ['name' => $name, 'value' => $value]];
        return DataService::save('SystemConfig', $data, 'name');
    }
    if (empty($config)) {
        $config = Db::name('SystemConfig')->column('name,value');
    }
    return isset($config[$name]) ? $config[$name] : '';
}

/**
 * 日期格式标准输出
 * @param string $datetime 输入日期
 * @param string $format 输出格式
 * @return false|string
 */
function format_datetime($datetime, $format = 'Y年m月d日 H:i:s')
{
    return date($format, strtotime($datetime));
}

/**
 * UTF8字符串加密
 * @param string $string
 * @return string
 */
function encode($string)
{
    list($chars, $length) = ['', strlen($string = iconv('utf-8', 'gbk', $string))];
    for ($i = 0; $i < $length; $i++) {
        $chars .= str_pad(base_convert(ord($string[$i]), 10, 36), 2, 0, 0);
    }
    return $chars;
}

/**
 * UTF8字符串解密
 * @param string $string
 * @return string
 */
function decode($string)
{
    $chars = '';
    foreach (str_split($string, 2) as $char) {
        $chars .= chr(intval(base_convert($char, 36, 10)));
    }
    return iconv('gbk', 'utf-8', $chars);
}

/**
 * 下载远程文件到本地
 * @param string $url 远程图片地址
 * @return string
 */
function local_image($url)
{
    return \service\FileService::download($url)['url'];
}

function get_channel_name($channel_id){
    return Db::name('sfzfChannelType')->where('id',$channel_id)->value('name');
}

function get_zz($channel_id,$field){
    return Db::name('sfzfChannelConfigZz')->where('channel_id',$channel_id)->value($field);
}

function get_zl($channel_id,$field){
    return Db::name('sfzfChannelConfigZl')->where('channel_id',$channel_id)->value($field);
}

function get_merchant($merchant_id){
    return Db::name('sfzfMerchant')->where('appid',$merchant_id)->value('name');
}

function get_pay_mode($channel_id){
    $channel_type_id = Db::name('sfzfChannel')->where('id',$channel_id)->value('channel_type_id');
    return Db::name('sfzfChannelType')->where('id',$channel_type_id)->value('name');
}
// 建设银行短信匹配
function ccb_check($content, &$bank_tail, &$amount, &$amount_tail){
    $pattern = '/您尾号([\d]{4})的储蓄卡账户(.*)支付机构提现收入人民币([\d]+)\.([\d]{2})元/';

    preg_match($pattern, $content, $bank_matches);
    if (isset($bank_matches[1]) && isset($bank_matches[2]) && $bank_matches[3]) {
        $bank_tail = $bank_matches[1];
        $amount = $bank_matches[3];
        $amount_tail = $bank_matches[4];
        return true;
    }else{
        return false;
    }
}
// 中国银行短信匹配
function boc_check($content, &$bank_tail, &$amount, &$amount_tail){
    $pattern = [
        '/您的借记卡账户(\d{4})，于\d+月\d+日网上支付收入人民币(\d+)\.(\d{2}).*中国银行.*/',
        '/您的借记卡账户(\d{4})，于\d+月\d+日收入\(网银跨行\)人民币([\d]+)\.([\d]{2}).*中国银行.*/',
        '/您的借记卡账户(\d{4})，于\d+月\d+日POS收入人民币(\d+)\.(\d{2}).*中国银行.*/'
    ];
    $bank_matches = [];
    foreach ($pattern as $key => $value) {
        preg_match($value, $content, $bank_matches);
        if (isset($bank_matches[1]) && isset($bank_matches[2]) && isset($bank_matches[3])) {
            break;
        }
    }
    if (isset($bank_matches[1]) && isset($bank_matches[2]) && $bank_matches[3]) {
        $bank_tail = $bank_matches[1];
        $amount = $bank_matches[2];
        $amount_tail = $bank_matches[3];
        return true;
    }else{
        return false;
    }
}


