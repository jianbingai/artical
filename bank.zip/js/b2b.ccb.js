

if(location.href.indexOf('b2b.ccb.com')>-1){
    _bank_read_data_pane();
    z();
}
function z_1(){
    setTimeout(() => {
        try {
            window.frames[0].document.getElementById('workEplatform').click();
            _next(c);
        } catch (error) {
            _add(z,z_1);
        }
    }, 1000);
}
function z(){
    setTimeout(() => {
        try {
            window.frames[0].document.querySelector('#pic1 img').click();
            _next(c);
        } catch (error) {
            console.log(error);
            _add(z_1,z);
        }
    }, 1000);
}

function c(){
    setTimeout(() => {
        _i++;
        try {
            var id=window.frames[0].document.querySelector('#tb0001 a[id]').getAttribute('id');//账户信息查询列表
            window.frames[0].document.querySelector('#ul'+id+' a[id]').click();//活期账户
            _next(a)
        } catch (e) {
            console.log(e);
            _add(z,c);
        }
    }, 3000);
}
function a(){
    setTimeout(() => {
        try{
            window.frames[0].frames[1].frames[1].document.querySelector('#jhform .tableList a[href]').click();//选择第一个账号
            _next(b);
        }catch(e){
            console.log(e);
            _add(c,a);
        }
    }, 3000);
}
function b(){
setTimeout(() => {
    try{
        window.frames[0].frames[1].document.querySelector('#jhform .tableList a[href]').click();//再次选择第一个账号
        _next(d);
    }catch(e){
        console.log(e);
        _add(a,b);
    }
}, 3000);
}
function d(){
setTimeout(() => {
    try {
        window.frames[0].frames[1].document.getElementsByName('commonDate')[0].click();//选择最近7天
        var st=window.frames[0].frames[1].document.getElementById('StDt');
        var et=window.frames[0].frames[1].document.getElementById('EdDt');
        var s=st.value;
        if(s==et.value){
            st.value=parseInt(s)-1;
        }
        window.frames[0].frames[1].document.getElementsByName('jhform')[0].submit();//提交
        _next(e);
    } catch (error) {
        console.log(error);
        _add(b,d);
    }
}, 3000);
}
function e(){
    setTimeout(() => {
        try {
            var trs=window.frames[0].frames[1].document.querySelectorAll('.tableList tr:nth-child(n+3)');
            var ks={jysj:1,zc:2,sr:3,ye:4,dfhm:5,dfzh:6,dfjg:7,jzrq:8,zy:9,bz:10};
            var arr=[];
            for(var i=0;i<trs.length;i++){
                var tds=trs[i].getElementsByTagName('td');
                var o={};
                for(k in ks){
                    o[k]=tds[ks[k]].innerText;
                }
                arr.push(o);
            }
            if(arr.length<1){
                try {
                    window.frames[0].frames[1].document.querySelector('.area_button input.button').click();
                } catch (error) {
                    
                }
            }
            console.log(arr);
            _submit(arr);
            var $as=window.frames[0].frames[1].document.querySelectorAll('.splitPage a[style]');
            for(var i=0;i<$as.length;i++){
                var $a=$as[i];
                if($a.innerText.indexOf('下一页')>-1){
                    $a.click();
                    _next(e);
                    return;
                }
            }
            window.frames[0].frames[1].document.getElementById('backButton').click();//返回
            setTimeout(() => {
                _next(d);
            }, 3000);
        } catch (error) {
            console.log(error);
            _add(d,e);
        }
    }, 1000);
}
// a();
// console.log(aid);
// function a(){
//     taskBar.createWin('5111','活期账户','N00001','','15');//进入活期账户列表

//     var id=window.frames[0].document.querySelector('#tb0001 a[id]').getAttribute('id');//账户信息查询列表
//     var a=window.frames[0].document.querySelector('#ul'+id+' a[id]');//活期账户
//     a.click();
// }